# Movie Audience Segmentation (Ratings Only)

Frontend-only ML app. React + Vite + Tailwind + K-Means clustering + Recharts + PapaParse + jsPDF + html2canvas.
No backend, no external APIs. Rating ingestion, feature engineering, clustering, and PDF report all run
in the browser.

Clustering uses the same lightweight from-scratch K-Means implementation as its sibling segmentation
projects (k-means++ init + Lloyd's algorithm, src/ml/kmeans.js) instead of the full TensorFlow.js bundle.

## Run it

npm install
npm run dev

Open the printed local URL. First load: ratings load, viewer profiles + rating features are built,
features are standardized (z-score), then K-Means runs (K=4 by default) before the dashboard is ready.

## Structure

- public/data/movie_ratings.csv — ~6,000 rating records, 252 viewers, 36 movies across 6 genres, 6 viewer
  archetypes (highly engaged, selective high-rating, casual, genre-focused, critical, frequent)
- src/ml/preprocessing.js — builds per-viewer rating features (avg, count, variance, min/max,
  consistency, per-genre averages) and standardizes them
- src/ml/kmeans.js / clustering.js — the algorithm and orchestration
- src/services/dataset.js — CSV loading/validation + genre/rating-distribution/movie-stats helpers
- src/utils/segmentInsights.js — per-cluster stats, rule-based audience naming, and per-viewer preference
  classification (rating level, rating activity, preference style)
- src/pages/ — Dashboard, Audience Segments, Rating Analysis, Cluster Performance
- src/components/ — Sidebar, Header, StatCard, ChartCard, SegmentCard, ViewerTable, ViewerDetails,
  ClusterVisualization, RatingBehaviorMatrix, ReportButton
- src/utils/reportGenerator.js — builds the downloadable PDF (jsPDF + html2canvas)

Swap in your own data by replacing public/data/movie_ratings.csv, keeping the same column names
(user_id, movie_id, movie_title, genre, rating). Genre feature columns are built dynamically from
whatever genres are present, so new genres show up automatically. Missing genre ratings for a viewer
fall back to that viewer's own overall average rather than a random value.

## Changing K

On the Audience Segments page, pick 2–6 clusters (default 4). Changing K re-runs K-Means, recalculates
centroids, reassigns every viewer, and updates all charts, segment cards, the rating behavior matrix,
and metrics.

## Report download

On the Audience Segments page, "Download Report" generates movie_audience_segmentation_report.pdf with
the dataset summary, current K, per-segment stats and insights, genre analysis, clustering metrics
(inertia, silhouette score), and the segmentation chart — all from the current session. Blocks with
"Please complete audience segmentation first" if clicked before clustering finishes.
