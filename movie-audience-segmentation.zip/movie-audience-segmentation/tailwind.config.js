/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: '#1D1A2E',
        slate: { 925: '#151228' },
        crimson: '#A9425B',
        amber3: '#C98A3D',
        indigo3: '#4E5FB8',
        paper: '#F7F6F9',
      },
      fontFamily: {
        sans: ['"Karla"', 'system-ui', 'sans-serif'],
        display: ['"Bricolage Grotesque"', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
