import React from 'react'
import { colorForCluster } from '../utils/colors'

function diversityLabel(genreSpreadZ) {
  if (genreSpreadZ > 0.5) return 'Low'
  if (genreSpreadZ < -0.5) return 'High'
  return 'Moderate'
}

function activityLabel(countZ) {
  if (countZ > 0.5) return 'High'
  if (countZ < -0.5) return 'Low'
  return 'Moderate'
}

export default function RatingBehaviorMatrix({ segments }) {
  return (
    <div className="bg-white rounded-lg border border-black/5 p-5">
      <h3 className="text-sm font-medium text-ink mb-1">Rating Behavior Matrix</h3>
      <p className="text-xs text-ink/40 mb-4">How each audience segment compares across key rating behaviors</p>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[600px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              <th className="py-2 pr-4">Segment</th>
              <th className="py-2 pr-4">Avg Rating</th>
              <th className="py-2 pr-4">Rating Activity</th>
              <th className="py-2 pr-4">Consistency</th>
              <th className="py-2 pr-4">Top Genre</th>
              <th className="py-2 pr-4">Genre Diversity</th>
            </tr>
          </thead>
          <tbody>
            {segments.map((s) => (
              <tr key={s.segment} className="border-b border-black/5 last:border-0">
                <td className="py-2 pr-4 whitespace-nowrap">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colorForCluster(s.segment) }} />
                    {s.name}
                  </span>
                </td>
                <td className="py-2 pr-4">{s.avgRating?.toFixed(2)}</td>
                <td className="py-2 pr-4">{activityLabel(s.countZ)}</td>
                <td className="py-2 pr-4">{((s.avgConsistency || 0) * 100).toFixed(0)}%</td>
                <td className="py-2 pr-4">{s.dominantGenre}</td>
                <td className="py-2 pr-4">{diversityLabel(s.genreSpreadZ)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
