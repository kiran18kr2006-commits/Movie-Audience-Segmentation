import React from 'react'
import { colorForCluster } from '../utils/colors'

export default function SegmentCard({ segment, onSelect, selected }) {
  return (
    <button
      onClick={onSelect}
      className={`w-full text-left bg-white rounded-lg border p-5 transition-colors ${
        selected ? 'border-ink' : 'border-black/5 hover:border-black/15'
      }`}
    >
      <div className="flex items-center gap-2 mb-1">
        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colorForCluster(segment.segment) }} />
        <p className="text-xs uppercase tracking-wide text-ink/40">Segment {segment.segment + 1}</p>
      </div>
      <h3 className="font-display text-lg text-ink mb-1">{segment.name}</h3>
      <p className="text-sm text-ink/50 mb-4">{segment.count} viewers · {segment.percentage.toFixed(1)}%</p>

      <div className="grid grid-cols-2 gap-3 text-sm mb-4">
        <div>
          <p className="text-xs text-ink/40">Avg Rating</p>
          <p className="font-medium text-ink">{segment.avgRating.toFixed(2)}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Avg Ratings / Viewer</p>
          <p className="font-medium text-ink">{segment.avgRatingCount.toFixed(0)}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Dominant Genre</p>
          <p className="font-medium text-ink">{segment.dominantGenre}</p>
        </div>
        <div>
          <p className="text-xs text-ink/40">Consistency</p>
          <p className="font-medium text-ink">{(segment.avgConsistency * 100).toFixed(0)}%</p>
        </div>
      </div>

      <p className="text-xs text-ink/50 leading-relaxed">{segment.summary}</p>
    </button>
  )
}
