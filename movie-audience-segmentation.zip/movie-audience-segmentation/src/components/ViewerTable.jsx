import React, { useMemo, useState } from 'react'
import { colorForCluster } from '../utils/colors'

const PAGE_SIZE = 10

const COLUMNS = [
  { key: 'user_id', label: 'User ID' },
  { key: 'ratingCount', label: 'Ratings Given' },
  { key: 'avgRating', label: 'Avg Rating' },
  { key: 'variance', label: 'Variance' },
  { key: 'dominantGenre', label: 'Dominant Genre' },
  { key: 'segment', label: 'Segment' },
]

export default function ViewerTable({ viewers, genres, segmentNames, onSelect, selectedId }) {
  const [search, setSearch] = useState('')
  const [segmentFilter, setSegmentFilter] = useState('all')
  const [genreFilter, setGenreFilter] = useState('all')
  const [sortKey, setSortKey] = useState('avgRating')
  const [sortDir, setSortDir] = useState('desc')
  const [page, setPage] = useState(1)

  const filtered = useMemo(() => {
    let result = viewers
    if (search.trim()) {
      const q = search.trim().toLowerCase()
      result = result.filter((v) => v.user_id.toLowerCase().includes(q))
    }
    if (segmentFilter !== 'all') {
      result = result.filter((v) => v.segment === Number(segmentFilter))
    }
    if (genreFilter !== 'all') {
      result = result.filter((v) => v.dominantGenre === genreFilter)
    }
    const sorted = [...result].sort((a, b) => {
      const av = a[sortKey]
      const bv = b[sortKey]
      const diff = typeof av === 'string' ? av.localeCompare(bv) : av - bv
      return sortDir === 'asc' ? diff : -diff
    })
    return sorted
  }, [viewers, search, segmentFilter, genreFilter, sortKey, sortDir])

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE))
  const currentPage = Math.min(page, totalPages)
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE)

  const toggleSort = (key) => {
    if (sortKey === key) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortKey(key)
      setSortDir('desc')
    }
    setPage(1)
  }

  return (
    <div className="bg-white rounded-lg border border-black/5 p-5 min-w-0">
      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <input
          type="text"
          placeholder="Search by User ID"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1) }}
          className="flex-1 border border-black/10 rounded-md px-3 py-2 text-sm min-w-0"
        />
        <select
          value={genreFilter}
          onChange={(e) => { setGenreFilter(e.target.value); setPage(1) }}
          className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="all">All Genres</option>
          {genres.map((g) => <option key={g} value={g}>{g}</option>)}
        </select>
        <select
          value={segmentFilter}
          onChange={(e) => { setSegmentFilter(e.target.value); setPage(1) }}
          className="border border-black/10 rounded-md px-3 py-2 text-sm bg-white"
        >
          <option value="all">All Segments</option>
          {segmentNames.map((s, i) => (
            <option key={i} value={i}>{s.name}</option>
          ))}
        </select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm min-w-[640px]">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
              {COLUMNS.map((col) => (
                <th
                  key={col.key}
                  onClick={() => toggleSort(col.key)}
                  className="py-2 pr-4 cursor-pointer select-none whitespace-nowrap"
                >
                  {col.label}{sortKey === col.key ? (sortDir === 'asc' ? ' ▲' : ' ▼') : ''}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {pageRows.map((v) => (
              <tr
                key={v.user_id}
                onClick={() => onSelect(v)}
                className={`border-b border-black/5 last:border-0 cursor-pointer hover:bg-black/[0.02] ${
                  selectedId === v.user_id ? 'bg-black/[0.03]' : ''
                }`}
              >
                <td className="py-2 pr-4 whitespace-nowrap">{v.user_id}</td>
                <td className="py-2 pr-4">{v.ratingCount}</td>
                <td className="py-2 pr-4">{v.avgRating.toFixed(2)}</td>
                <td className="py-2 pr-4">{v.variance.toFixed(2)}</td>
                <td className="py-2 pr-4">{v.dominantGenre}</td>
                <td className="py-2 pr-4 whitespace-nowrap">
                  <span className="inline-flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colorForCluster(v.segment) }} />
                    {segmentNames[v.segment]?.name}
                  </span>
                </td>
              </tr>
            ))}
            {pageRows.length === 0 && (
              <tr>
                <td colSpan={COLUMNS.length} className="py-6 text-center text-ink/40">No viewers match your filters.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between mt-4 text-sm text-ink/50">
        <span>{filtered.length} viewers</span>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            disabled={currentPage <= 1}
            className="px-3 py-1 rounded border border-black/10 disabled:opacity-40"
          >
            Prev
          </button>
          <span>{currentPage} / {totalPages}</span>
          <button
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage >= totalPages}
            className="px-3 py-1 rounded border border-black/10 disabled:opacity-40"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  )
}
