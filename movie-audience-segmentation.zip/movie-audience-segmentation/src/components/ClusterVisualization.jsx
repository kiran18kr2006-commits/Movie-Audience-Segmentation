import React from 'react'
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import ChartCard from './ChartCard'
import { colorForCluster } from '../utils/colors'

function CustomTooltip({ active, payload }) {
  if (!active || !payload || !payload.length) return null
  const v = payload[0].payload
  return (
    <div className="bg-white border border-black/10 rounded-md px-3 py-2 text-xs shadow-sm">
      <p className="font-medium text-ink mb-1">{v.user_id}</p>
      <p className="text-ink/60">Avg Rating: {v.avgRating.toFixed(2)}</p>
      <p className="text-ink/60">Ratings Given: {v.ratingCount}</p>
      <p className="text-ink/60">Dominant Genre: {v.dominantGenre}</p>
      <p className="text-ink/60">Segment: {v.segment + 1}</p>
    </div>
  )
}

export default function ClusterVisualization({ viewers, description, innerRef }) {
  return (
    <ChartCard innerRef={innerRef} title="Average Rating vs Rating Activity" description={description || 'Each point is one viewer, colored by segment'}>
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
          <CartesianGrid stroke="#ece8f0" />
          <XAxis type="number" dataKey="ratingCount" name="Rating Activity" tick={{ fontSize: 11 }} />
          <YAxis type="number" dataKey="avgRating" name="Average Rating" domain={[1, 5]} tick={{ fontSize: 11 }} />
          <Tooltip content={<CustomTooltip />} />
          <Scatter data={viewers}>
            {viewers.map((v, i) => (
              <Cell key={i} fill={colorForCluster(v.segment)} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </ChartCard>
  )
}
