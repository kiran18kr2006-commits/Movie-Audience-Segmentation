import React from 'react'
import { colorForCluster } from '../utils/colors'
import { viewerBehaviorSummary, viewerPreferenceProfile } from '../utils/segmentInsights'

export default function ViewerDetails({ viewer, segmentNames, overallStats, spreadMean, spreadStd }) {
  if (!viewer) {
    return (
      <div className="bg-white rounded-lg border border-black/5 border-dashed p-6 text-center text-ink/40 text-sm">
        Select a viewer from the table to see their details.
      </div>
    )
  }

  const segment = segmentNames[viewer.segment]
  const profile = viewerPreferenceProfile(viewer, overallStats, spreadMean, spreadStd)

  const rows = [
    ['Total Ratings', viewer.ratingCount],
    ['Average Rating', viewer.avgRating.toFixed(2)],
    ['Minimum Rating', viewer.minRating],
    ['Maximum Rating', viewer.maxRating],
    ['Rating Variance', viewer.variance.toFixed(2)],
    ['Consistency', `${(viewer.consistency * 100).toFixed(0)}%`],
  ]

  const genreRows = Object.entries(viewer.genreAverages).sort((a, b) => b[1] - a[1])

  return (
    <div className="bg-white rounded-lg border border-black/5 p-6 min-w-0">
      <div className="flex items-center gap-2 mb-1">
        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: colorForCluster(viewer.segment) }} />
        <p className="text-xs uppercase tracking-wide text-ink/40">Assigned Segment</p>
      </div>
      <h3 className="font-display text-xl text-ink mb-1">{segment?.name}</h3>
      <p className="text-sm text-ink/50 mb-4">{viewer.user_id}</p>

      <div className="space-y-2 mb-5">
        {rows.map(([label, value]) => (
          <div key={label} className="flex justify-between text-sm py-1.5 border-b border-black/5 last:border-0">
            <span className="text-ink/50">{label}</span>
            <span className="text-ink font-medium">{value}</span>
          </div>
        ))}
      </div>

      <div className="mb-4">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Preference Profile</p>
        <div className="grid grid-cols-1 gap-1.5 text-xs">
          <div className="bg-paper rounded px-2 py-1.5"><span className="text-ink/50">Rating Level:</span> <span className="text-ink font-medium">{profile.ratingLevel}</span></div>
          <div className="bg-paper rounded px-2 py-1.5"><span className="text-ink/50">Rating Activity:</span> <span className="text-ink font-medium">{profile.ratingActivity}</span></div>
          <div className="bg-paper rounded px-2 py-1.5"><span className="text-ink/50">Preference Style:</span> <span className="text-ink font-medium">{profile.preferenceStyle}</span></div>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Genre Preferences</p>
        <div className="space-y-1">
          {genreRows.map(([genre, value]) => (
            <div key={genre} className="flex justify-between text-xs py-1 border-b border-black/5 last:border-0">
              <span className="text-ink/60">{genre}</span>
              <span className="text-ink font-medium">{value.toFixed(2)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mb-4">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-2">Rating History</p>
        <div className="max-h-40 overflow-y-auto space-y-1">
          {viewer.history.map((h) => (
            <div key={h.movie_id} className="flex justify-between text-xs py-1 border-b border-black/5 last:border-0">
              <span className="text-ink/60 truncate pr-2">{h.movie_title} <span className="text-ink/30">({h.genre})</span></span>
              <span className="text-ink font-medium flex-shrink-0">{h.rating}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-paper rounded-md p-4">
        <p className="text-xs uppercase tracking-wide text-ink/40 mb-1">Behavior Summary</p>
        <p className="text-sm text-ink/70">{viewerBehaviorSummary(viewer, overallStats)}</p>
      </div>
    </div>
  )
}
