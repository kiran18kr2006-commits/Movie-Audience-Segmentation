import { computeMeanStd } from '../ml/preprocessing'

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

function genreSpread(viewer) {
  const values = Object.values(viewer.genreAverages)
  return Math.max(...values) - Math.min(...values)
}

function meanStdOf(values) {
  const mean = avg(values)
  const variance = avg(values.map((v) => (v - mean) ** 2))
  return { mean, std: Math.sqrt(variance) || 1 }
}

/** Computes per-cluster averages from the labeled viewer list. */
export function computeClusterStats(viewers, k) {
  const total = viewers.length
  const stats = []
  for (let c = 0; c < k; c++) {
    const members = viewers.filter((v) => v.segment === c)
    if (members.length === 0) {
      stats.push(null)
      continue
    }

    const genreCounts = {}
    members.forEach((m) => { genreCounts[m.dominantGenre] = (genreCounts[m.dominantGenre] || 0) + 1 })
    const dominantGenre = Object.entries(genreCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || '—'

    stats.push({
      segment: c,
      count: members.length,
      percentage: (members.length / total) * 100,
      avgRating: avg(members.map((m) => m.avgRating)),
      avgRatingCount: avg(members.map((m) => m.ratingCount)),
      avgVariance: avg(members.map((m) => m.variance)),
      avgConsistency: avg(members.map((m) => m.consistency)),
      avgGenreSpread: avg(members.map((m) => genreSpread(m))),
      dominantGenre,
    })
  }
  return stats
}

/**
 * Assigns a business-friendly name to each cluster based on how its averages
 * compare (z-score) to the overall viewer population. Falls back to a
 * generic label on collisions so every segment still gets a distinct name.
 */
export function nameSegments(viewers, clusterStats) {
  const overall = computeMeanStd(viewers)
  const spreadStats = meanStdOf(viewers.map((v) => genreSpread(v)))

  const zscore = (value, col) => (value - overall[col].mean) / overall[col].std
  const spreadZ = (value) => (value - spreadStats.mean) / spreadStats.std

  const scored = clusterStats.map((stat) => {
    if (!stat) return null
    return {
      ...stat,
      avgZ: zscore(stat.avgRating, 'avgRating'),
      countZ: zscore(stat.avgRatingCount, 'ratingCount'),
      varianceZ: zscore(stat.avgVariance, 'variance'),
      genreSpreadZ: spreadZ(stat.avgGenreSpread),
    }
  })

  const used = new Set()
  const pick = (name) => {
    if (!used.has(name)) {
      used.add(name)
      return name
    }
    return null
  }

  return scored.map((s) => {
    if (!s) return { name: 'Empty Segment', summary: 'No viewers were assigned to this cluster.' }

    let name = null
    if (s.countZ > 0.75 && s.avgZ > 0.5) name = pick('Highly Engaged Viewers')
    if (!name && s.countZ < -0.25 && s.avgZ > 0.75 && s.varianceZ < -0.25) name = pick('Selective High-Rating Viewers')
    if (!name && s.genreSpreadZ > 0.75) name = pick('Genre-Focused Viewers')
    if (!name && s.avgZ < -0.75) name = pick('Critical Rating Viewers')
    if (!name && s.countZ > 0.75) name = pick('Frequent Movie Viewers')
    if (!name && s.genreSpreadZ < -0.5) name = pick('Broad Preference Viewers')
    if (!name) name = pick('Casual Movie Viewers')
    if (!name) name = `Audience Segment ${s.segment + 1}`

    const summary = buildSummary(name, s)
    return { name, summary, ...s }
  })
}

function buildSummary(name, s) {
  const ratingPart = s.avgZ > 0.5 ? 'high ratings' : s.avgZ < -0.5 ? 'low ratings' : 'moderate ratings'
  const activityPart = s.countZ > 0.5 ? 'frequent rating activity' : s.countZ < -0.5 ? 'limited rating activity' : 'moderate rating activity'
  return `${name} tend to give ${ratingPart} with ${activityPart}, most often favoring ${s.dominantGenre}.`
}

const LEVEL_TOLERANCE = 0.5

function classifyLevel(zvalue, highLabel, lowLabel, midLabel) {
  if (zvalue > LEVEL_TOLERANCE) return highLabel
  if (zvalue < -LEVEL_TOLERANCE) return lowLabel
  return midLabel
}

/** Dataset-threshold-based preference classification for one viewer. */
export function viewerPreferenceProfile(viewer, overallStats, spreadMean, spreadStd) {
  const z = (col) => (viewer[col] - overallStats[col].mean) / overallStats[col].std
  const spread = genreSpread(viewer)
  const spreadZ = (spread - spreadMean) / spreadStd

  return {
    ratingLevel: classifyLevel(z('avgRating'), 'High Rating', 'Low Rating', 'Moderate Rating'),
    ratingActivity: classifyLevel(z('ratingCount'), 'High Activity', 'Low Activity', 'Moderate Activity'),
    preferenceStyle: spreadZ > 0.5 ? 'Genre Focused' : spreadZ < -0.5 ? 'Broad Preference' : 'Balanced Preference',
  }
}

/** One-line rating-behavior summary for a single viewer, used in the detail panel. */
export function viewerBehaviorSummary(viewer, overallStats) {
  const ratingHigh = viewer.avgRating > overallStats.avgRating.mean
  const activityHigh = viewer.ratingCount > overallStats.ratingCount.mean

  const ratingPart = ratingHigh ? 'rates movies highly' : 'rates movies more critically than average'
  const activityPart = activityHigh ? 'rates frequently' : 'rates infrequently'

  return `This viewer ${ratingPart} and ${activityPart}, favoring ${viewer.dominantGenre}.`
}

export { genreSpread, meanStdOf }
