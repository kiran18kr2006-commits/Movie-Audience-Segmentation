export const CLUSTER_COLORS = ['#A9425B', '#4E5FB8', '#C98A3D', '#3E8265', '#8E5CC7', '#4B7A8E']

export function colorForCluster(index) {
  return CLUSTER_COLORS[index % CLUSTER_COLORS.length]
}
