import jsPDF from 'jspdf'
import html2canvas from 'html2canvas'

const APP_NAME = 'Movie Audience Segmentation Report'

/**
 * Builds and downloads a PDF audience-segmentation report.
 * chartElement is an optional DOM node captured as an image and embedded
 * in the PDF. If capture fails, the report still generates without it.
 */
export async function generateSegmentationReportPdf({ summary, k, segments, clustering, genreInsights, chartElement }) {
  if (!segments || segments.length === 0) {
    throw new Error('Please complete audience segmentation first.')
  }
  if (!clustering) {
    throw new Error('Clustering metrics are not available yet. Please wait for segmentation to finish.')
  }

  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const margin = 48
  let y = margin

  const ensureSpace = (needed) => {
    if (y + needed > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
  }

  const line = (text, size = 11, weight = 'normal', gap = 16) => {
    ensureSpace(gap)
    doc.setFont('helvetica', weight)
    doc.setFontSize(size)
    doc.text(text, margin, y)
    y += gap
  }

  // Cover / header
  doc.setFillColor(29, 26, 46)
  doc.rect(0, 0, pageWidth, 90, 'F')
  doc.setTextColor(255, 255, 255)
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(17)
  doc.text(APP_NAME, margin, 32)
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(9)
  doc.text(`Report generated: ${new Date().toLocaleString()}`, margin, 50)
  doc.text(`Viewers: ${summary.totalViewers}  |  Movies: ${summary.totalMovies}  |  Ratings: ${summary.totalRatings}  |  K: ${k}`, margin, 66)
  doc.setTextColor(29, 26, 46)
  y = 118

  // Dataset summary
  line('Dataset Summary', 13, 'bold', 20)
  line(`Total Viewers: ${summary.totalViewers}`)
  line(`Total Movies: ${summary.totalMovies}`)
  line(`Total Ratings: ${summary.totalRatings}`)
  line(`Average Rating: ${summary.averageRating.toFixed(2)}`)
  line(`Average Ratings Per Viewer: ${summary.averageRatingsPerViewer.toFixed(1)}`)
  y += 8

  // Cluster performance
  line('Cluster Performance', 13, 'bold', 20)
  line(`Number of Clusters (K): ${k}`)
  line(`Inertia: ${clustering.inertia.toFixed(3)}`)
  line(`Silhouette Score: ${clustering.silhouette.toFixed(3)}`)
  y += 8

  // Rating analysis / genre insights
  if (genreInsights && genreInsights.length) {
    line('Genre Analysis', 13, 'bold', 20)
    genreInsights.forEach((g) => {
      line(`${g.genre}: ${g.ratingCount} ratings, avg ${g.avgRating.toFixed(2)}, ${g.viewerCount} viewers`, 10)
    })
    y += 8
  }

  // Audience segments
  line('Audience Segments', 13, 'bold', 20)
  segments.forEach((s) => {
    ensureSpace(110)
    line(`${s.name} (Segment ${s.segment + 1})`, 12, 'bold', 16)
    line(`Viewer Count: ${s.count}  (${s.percentage.toFixed(1)}%)`)
    line(`Average Rating: ${s.avgRating.toFixed(2)}`)
    line(`Average Ratings Per Viewer: ${s.avgRatingCount.toFixed(1)}`)
    line(`Dominant Genre: ${s.dominantGenre}`)
    const wrapped = doc.splitTextToSize(s.summary, pageWidth - margin * 2)
    ensureSpace(wrapped.length * 14 + 10)
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(10)
    doc.text(wrapped, margin, y)
    y += wrapped.length * 14 + 14
  })

  // Chart (best effort)
  if (chartElement) {
    try {
      const canvas = await html2canvas(chartElement, { backgroundColor: '#ffffff', scale: 2 })
      const imgData = canvas.toDataURL('image/png')
      const imgWidth = pageWidth - margin * 2
      const imgHeight = (canvas.height / canvas.width) * imgWidth

      ensureSpace(imgHeight + 24)
      line('Audience Segmentation Visualization', 13, 'bold', 20)
      doc.addImage(imgData, 'PNG', margin, y, imgWidth, imgHeight)
      y += imgHeight + 10
    } catch (err) {
      line('Audience Segmentation Visualization', 13, 'bold', 20)
      doc.setFont('helvetica', 'italic')
      doc.setFontSize(10)
      doc.text('Chart could not be rendered for this report.', margin, y)
      y += 18
    }
  }

  doc.save('movie_audience_segmentation_report.pdf')
}
