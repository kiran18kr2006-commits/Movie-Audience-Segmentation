import React, { useMemo } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { computeSummary, genreAnalysis, ratingDistribution } from '../services/dataset'
import { colorForCluster } from '../utils/colors'

export default function Dashboard({ ratings, viewers, segments, k }) {
  const summary = computeSummary(ratings, viewers)
  const genreData = useMemo(() => genreAnalysis(ratings), [ratings])
  const ratingDist = useMemo(() => ratingDistribution(ratings), [ratings])

  const distribution = segments.map((s) => ({ name: s.name, count: s.count, segment: s.segment }))
  const avgRatingBySegment = segments.map((s) => ({ name: s.name, avgRating: Number(s.avgRating.toFixed(2)), segment: s.segment }))
  const activityBySegment = segments.map((s) => ({ name: s.name, activity: Number(s.avgRatingCount.toFixed(1)), segment: s.segment }))

  const largestSegment = [...segments].sort((a, b) => b.count - a.count)[0]

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3">
        <StatCard label="Total Viewers" value={summary.totalViewers} />
        <StatCard label="Total Movies" value={summary.totalMovies} />
        <StatCard label="Total Audience Segments" value={k} />
        <StatCard label="Average Rating" value={summary.averageRating.toFixed(2)} />
        <StatCard label="Average Ratings Per Viewer" value={summary.averageRatingsPerViewer.toFixed(1)} />
        <StatCard label="Highest Rated Movie" value={summary.highestRatedMovie} />
      </div>

      {largestSegment && (
        <div className="bg-white rounded-lg border border-black/5 px-5 py-3 text-sm text-ink/70">
          Most viewers belong to the <span className="font-medium text-ink">{largestSegment.name}</span> segment
          ({largestSegment.count} viewers, {largestSegment.percentage.toFixed(1)}%).
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Audience Segment Distribution" description="Number of viewers per segment">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={distribution} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                {distribution.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Rating by Segment">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={avgRatingBySegment} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} domain={[1, 5]} />
              <Tooltip />
              <Bar dataKey="avgRating" radius={[4, 4, 0, 0]}>
                {avgRatingBySegment.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Rating Distribution" description="Count of ratings by star value">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ratingDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="rating" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#A9425B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Genre Average Ratings">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={genreData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="genre" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[1, 5]} />
              <Tooltip />
              <Bar dataKey="avgRating" fill="#4E5FB8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Rating Activity by Segment" description="Average ratings given per viewer" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={activityBySegment} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="name" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Bar dataKey="activity" radius={[4, 4, 0, 0]}>
                {activityBySegment.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  )
}
