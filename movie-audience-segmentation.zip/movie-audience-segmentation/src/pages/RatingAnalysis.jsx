import React, { useMemo, useState } from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import ViewerTable from '../components/ViewerTable'
import ViewerDetails from '../components/ViewerDetails'
import {
  computeSummary, genreAnalysis, ratingDistribution, medianRating, mostCommonRating, movieRatingStats,
} from '../services/dataset'
import { computeMeanStd } from '../ml/preprocessing'
import { genreSpread, meanStdOf } from '../utils/segmentInsights'

function histogram(values, buckets = 6) {
  const min = Math.min(...values)
  const max = Math.max(...values)
  const width = (max - min) / buckets || 1
  const bins = Array.from({ length: buckets }, (_, i) => ({
    range: `${Math.round(min + i * width)}-${Math.round(min + (i + 1) * width)}`,
    count: 0,
  }))
  values.forEach((v) => {
    let idx = Math.floor((v - min) / width)
    if (idx >= buckets) idx = buckets - 1
    if (idx < 0) idx = 0
    bins[idx].count += 1
  })
  return bins
}

export default function RatingAnalysis({ ratings, viewers, genres, segments }) {
  const [selected, setSelected] = useState(null)
  const summary = computeSummary(ratings, viewers)
  const overallStats = useMemo(() => computeMeanStd(viewers), [viewers])
  const spreadStats = useMemo(() => meanStdOf(viewers.map((v) => genreSpread(v))), [viewers])

  const genreData = useMemo(() => genreAnalysis(ratings), [ratings])
  const ratingDist = useMemo(() => ratingDistribution(ratings), [ratings])
  const ratingsPerViewerDist = useMemo(() => histogram(viewers.map((v) => v.ratingCount)), [viewers])
  const topMovies = useMemo(() => [...movieRatingStats(ratings)].sort((a, b) => b.ratingCount - a.ratingCount).slice(0, 8), [ratings])

  const median = medianRating(ratings)
  const mostCommon = mostCommonRating(ratings)
  const uniqueMovies = new Set(ratings.map((r) => r.movie_id)).size
  const avgRatingsPerMovie = ratings.length / uniqueMovies

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3">
        <StatCard label="Average Rating" value={summary.averageRating.toFixed(2)} />
        <StatCard label="Median Rating" value={median} />
        <StatCard label="Most Common Rating" value={mostCommon} />
        <StatCard label="Total Ratings" value={summary.totalRatings} />
        <StatCard label="Average Ratings Per Viewer" value={summary.averageRatingsPerViewer.toFixed(1)} />
        <StatCard label="Average Ratings Per Movie" value={avgRatingsPerMovie.toFixed(1)} />
      </div>

      <div className="grid md:grid-cols-2 gap-5">
        <ChartCard title="Rating Distribution">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ratingDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="rating" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#A9425B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Average Rating by Genre">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={genreData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="genre" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[1, 5]} />
              <Tooltip />
              <Bar dataKey="avgRating" fill="#4E5FB8" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Ratings Per Viewer" description="How many ratings viewers tend to give">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={ratingsPerViewerDist} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="range" tick={{ fontSize: 9 }} interval={0} angle={-20} textAnchor="end" height={50} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#C98A3D" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Ratings Per Movie" description="Most-rated movies">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topMovies} layout="vertical" margin={{ top: 10, right: 20, bottom: 0, left: 10 }}>
              <CartesianGrid stroke="#ece8f0" horizontal={false} />
              <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
              <YAxis type="category" dataKey="movie_title" tick={{ fontSize: 10 }} width={120} />
              <Tooltip />
              <Bar dataKey="ratingCount" fill="#8E5CC7" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Genre Preference Comparison" description="Number of viewers rating each genre" className="md:col-span-2">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={genreData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
              <CartesianGrid stroke="#ece8f0" vertical={false} />
              <XAxis dataKey="genre" tick={{ fontSize: 10 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="viewerCount" fill="#A9425B" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 min-w-0">
          <ViewerTable
            viewers={viewers}
            genres={genres}
            segmentNames={segments}
            onSelect={setSelected}
            selectedId={selected?.user_id}
          />
        </div>
        <ViewerDetails
          viewer={selected}
          segmentNames={segments}
          overallStats={overallStats}
          spreadMean={spreadStats.mean}
          spreadStd={spreadStats.std}
        />
      </div>
    </div>
  )
}
