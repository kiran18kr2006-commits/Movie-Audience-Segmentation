import React from 'react'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import StatCard from '../components/StatCard'
import ChartCard from '../components/ChartCard'
import { colorForCluster } from '../utils/colors'

export default function ClusterPerformance({ viewers, segments, k, clustering }) {
  const sizeData = segments.map((s) => ({ name: s.name, count: s.count, segment: s.segment }))

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Selected K" value={k} />
        <StatCard label="Total Viewers" value={viewers.length} />
        <StatCard label="Inertia" value={clustering.inertia.toFixed(2)} sublabel="Lower is tighter clusters" />
        <StatCard label="Silhouette Score" value={clustering.silhouette.toFixed(3)} sublabel="Closer to 1 is better separation" />
      </div>

      <ChartCard title="Cluster Sizes" description="Number of viewers assigned to each segment">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={sizeData} margin={{ top: 10, right: 10, bottom: 0, left: -10 }}>
            <CartesianGrid stroke="#ece8f0" vertical={false} />
            <XAxis dataKey="name" tick={{ fontSize: 9 }} interval={0} angle={-15} textAnchor="end" height={50} />
            <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="count" radius={[4, 4, 0, 0]}>
              {sizeData.map((d, i) => <Cell key={i} fill={colorForCluster(d.segment)} />)}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <div className="bg-white rounded-lg border border-black/5 p-5">
        <h3 className="text-sm font-medium text-ink mb-4">Cluster Table</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[560px]">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-ink/40 border-b border-black/5">
                <th className="py-2 pr-4">Segment</th>
                <th className="py-2 pr-4">Viewers</th>
                <th className="py-2 pr-4">Percentage</th>
                <th className="py-2 pr-4">Average Rating</th>
                <th className="py-2 pr-4">Rating Activity</th>
                <th className="py-2 pr-4">Dominant Genre</th>
              </tr>
            </thead>
            <tbody>
              {segments.map((s) => (
                <tr key={s.segment} className="border-b border-black/5 last:border-0">
                  <td className="py-2 pr-4 whitespace-nowrap">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: colorForCluster(s.segment) }} />
                      {s.name}
                    </span>
                  </td>
                  <td className="py-2 pr-4">{s.count}</td>
                  <td className="py-2 pr-4">{s.percentage.toFixed(1)}%</td>
                  <td className="py-2 pr-4">{s.avgRating.toFixed(2)}</td>
                  <td className="py-2 pr-4">{s.avgRatingCount.toFixed(1)}</td>
                  <td className="py-2 pr-4">{s.dominantGenre}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
