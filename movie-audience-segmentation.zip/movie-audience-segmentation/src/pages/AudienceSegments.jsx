import React, { useRef, useState } from 'react'
import SegmentCard from '../components/SegmentCard'
import ClusterVisualization from '../components/ClusterVisualization'
import RatingBehaviorMatrix from '../components/RatingBehaviorMatrix'
import ReportButton from '../components/ReportButton'
import { computeSummary, genreAnalysis } from '../services/dataset'

const K_OPTIONS = [2, 3, 4, 5, 6]

export default function AudienceSegments({ ratings, viewers, segments, k, onKChange, clustering }) {
  const [selectedSegment, setSelectedSegment] = useState(null)
  const chartRef = useRef(null)
  const summary = computeSummary(ratings, viewers)
  const genreInsights = genreAnalysis(ratings)

  const highlighted = selectedSegment === null
    ? viewers
    : viewers.filter((v) => v.segment === selectedSegment)

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg border border-black/5 p-4 flex flex-col sm:flex-row sm:items-center gap-3 justify-between">
        <div>
          <p className="text-sm text-ink/70 font-medium mb-1">Number of Clusters</p>
          <div className="flex gap-2">
            {K_OPTIONS.map((opt) => (
              <button
                key={opt}
                onClick={() => onKChange(opt)}
                className={`w-9 h-9 rounded-md text-sm font-medium transition-colors ${
                  k === opt ? 'bg-ink text-white' : 'bg-black/5 text-ink/60 hover:bg-black/10'
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        </div>
        <ReportButton
          summary={summary}
          k={k}
          segments={segments}
          clustering={clustering}
          genreInsights={genreInsights}
          chartElement={chartRef.current}
        />
      </div>

      <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
        {segments.map((s) => (
          <SegmentCard
            key={s.segment}
            segment={s}
            selected={selectedSegment === s.segment}
            onSelect={() => setSelectedSegment(selectedSegment === s.segment ? null : s.segment)}
          />
        ))}
      </div>

      <ClusterVisualization
        innerRef={chartRef}
        viewers={highlighted}
        description={selectedSegment === null ? 'Each point is one viewer, colored by segment' : `Highlighting ${segments[selectedSegment]?.name}`}
      />

      <RatingBehaviorMatrix segments={segments} />
    </div>
  )
}
