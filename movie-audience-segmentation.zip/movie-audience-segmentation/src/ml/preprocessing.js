export const NUMERIC_FEATURE_COLUMNS = [
  'avgRating',
  'ratingCount',
  'variance',
  'minRating',
  'maxRating',
  'consistency',
]

/** Builds one feature row per viewer from raw rating records. */
export function buildUserFeatures(ratings, genres) {
  const byUser = {}
  ratings.forEach((r) => {
    if (!byUser[r.user_id]) {
      byUser[r.user_id] = { user_id: r.user_id, history: [] }
    }
    byUser[r.user_id].history.push({ movie_id: r.movie_id, movie_title: r.movie_title, genre: r.genre, rating: r.rating })
  })

  return Object.values(byUser).map((u) => {
    const values = u.history.map((h) => h.rating)
    const ratingCount = values.length
    const avgRating = values.reduce((a, b) => a + b, 0) / ratingCount
    const variance = values.reduce((a, v) => a + (v - avgRating) ** 2, 0) / ratingCount
    const minRating = Math.min(...values)
    const maxRating = Math.max(...values)
    const consistency = 1 / (1 + Math.sqrt(variance)) // 0..1, higher = more consistent

    const genreAverages = {}
    genres.forEach((genre) => {
      const genreRatings = u.history.filter((h) => h.genre === genre).map((h) => h.rating)
      // No random fill for missing genres — fall back to the viewer's own overall average,
      // a neutral value consistent with "they'd probably rate it about like everything else".
      genreAverages[genre] = genreRatings.length
        ? genreRatings.reduce((a, b) => a + b, 0) / genreRatings.length
        : avgRating
    })

    const dominantGenre = Object.entries(genreAverages).sort((a, b) => b[1] - a[1])[0]?.[0] || genres[0]

    return {
      user_id: u.user_id,
      ratingCount,
      avgRating,
      variance,
      minRating,
      maxRating,
      consistency,
      genreAverages,
      dominantGenre,
      history: u.history,
    }
  })
}

export function computeStandardizationStats(userFeatures, genres) {
  const columns = [...NUMERIC_FEATURE_COLUMNS, ...genres.map((g) => `genre:${g}`)]
  const stats = {}
  columns.forEach((col) => {
    const values = userFeatures.map((u) => valueForColumn(u, col))
    const mean = values.reduce((a, b) => a + b, 0) / values.length
    const variance = values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length
    stats[col] = { mean, std: Math.sqrt(variance) || 1 }
  })
  return stats
}

function valueForColumn(user, col) {
  if (col.startsWith('genre:')) {
    return user.genreAverages[col.slice(6)]
  }
  return user[col]
}

export function standardize(value, mean, std) {
  return (value - mean) / std
}

export function buildFeatureMatrix(userFeatures, stats, genres) {
  const columns = [...NUMERIC_FEATURE_COLUMNS, ...genres.map((g) => `genre:${g}`)]
  return userFeatures.map((user) =>
    columns.map((col) => standardize(valueForColumn(user, col), stats[col].mean, stats[col].std)),
  )
}

export function computeMeanStd(userFeatures) {
  const result = {}
  NUMERIC_FEATURE_COLUMNS.forEach((col) => {
    const values = userFeatures.map((u) => u[col])
    const mean = values.reduce((a, b) => a + b, 0) / values.length
    const variance = values.reduce((a, v) => a + (v - mean) ** 2, 0) / values.length
    result[col] = { mean, std: Math.sqrt(variance) || 1 }
  })
  return result
}
