import { buildUserFeatures, computeStandardizationStats, buildFeatureMatrix } from './preprocessing'
import { runKMeans, computeInertia, computeSilhouetteScore } from './kmeans'
import { uniqueGenres } from '../services/dataset'

/**
 * Runs the full pipeline: build viewer-level rating features from raw
 * ratings, then cluster those features for a given K.
 */
export function segmentViewers(ratings, k) {
  const genres = uniqueGenres(ratings)
  const userFeatures = buildUserFeatures(ratings, genres)

  const stats = computeStandardizationStats(userFeatures, genres)
  const matrix = buildFeatureMatrix(userFeatures, stats, genres)

  const { assignments, centroids, iterations } = runKMeans(matrix, k, { seed: 42 })
  const inertia = computeInertia(matrix, assignments, centroids)
  const silhouette = computeSilhouetteScore(matrix, assignments, k)

  const viewers = userFeatures.map((u, i) => ({ ...u, segment: assignments[i] }))

  const clusterSizes = new Array(k).fill(0)
  assignments.forEach((c) => { clusterSizes[c] += 1 })

  return {
    k,
    genres,
    stats,
    viewers,
    assignments,
    centroids,
    iterations,
    inertia,
    silhouette,
    clusterSizes,
  }
}
