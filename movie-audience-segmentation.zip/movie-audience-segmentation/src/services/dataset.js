import Papa from 'papaparse'

const RATING_MIN = 1
const RATING_MAX = 5

/** Loads and parses the raw movie ratings dataset shipped with the app. */
export async function loadDataset() {
  let response
  try {
    response = await fetch('/data/movie_ratings.csv')
  } catch (err) {
    throw new Error('Could not reach the dataset file. Check your connection and reload.')
  }

  if (!response.ok) {
    throw new Error(`Dataset file not found (status ${response.status}). Expected public/data/movie_ratings.csv.`)
  }

  const csvText = await response.text()

  const parsed = Papa.parse(csvText, {
    header: true,
    dynamicTyping: true,
    skipEmptyLines: true,
  })

  if (parsed.errors && parsed.errors.length > 0) {
    throw new Error('The dataset CSV is malformed and could not be parsed.')
  }

  const seen = new Set()
  const rows = parsed.data.filter((row) => {
    const valid = typeof row.user_id === 'string' && row.user_id.trim().length > 0
      && typeof row.movie_id === 'string' && row.movie_id.trim().length > 0
      && typeof row.movie_title === 'string' && row.movie_title.trim().length > 0
      && typeof row.genre === 'string' && row.genre.trim().length > 0
      && typeof row.rating === 'number' && !Number.isNaN(row.rating)
      && row.rating >= RATING_MIN && row.rating <= RATING_MAX

    if (!valid) return false

    const key = `${row.user_id}::${row.movie_id}`
    if (seen.has(key)) return false // drop duplicate rating records
    seen.add(key)
    return true
  })

  if (rows.length < 100) {
    throw new Error('Dataset has too few valid rating records to build reliable viewer profiles.')
  }

  const uniqueUsers = new Set(rows.map((r) => r.user_id)).size
  if (uniqueUsers < 20) {
    throw new Error('Dataset has too few viewers to run reliable clustering.')
  }

  return rows
}

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length

export function uniqueGenres(ratings) {
  return [...new Set(ratings.map((r) => r.genre))].sort()
}

export function computeSummary(ratings, viewers) {
  const uniqueMovies = new Set(ratings.map((r) => r.movie_id)).size
  const movieAverages = movieRatingStats(ratings)
  const highestRated = [...movieAverages].sort((a, b) => b.avgRating - a.avgRating)[0]

  return {
    totalViewers: viewers.length,
    totalMovies: uniqueMovies,
    totalRatings: ratings.length,
    averageRating: avg(ratings.map((r) => r.rating)),
    averageRatingsPerViewer: avg(viewers.map((v) => v.ratingCount)),
    highestRatedMovie: highestRated ? highestRated.movie_title : '—',
  }
}

export function movieRatingStats(ratings) {
  const byMovie = {}
  ratings.forEach((r) => {
    if (!byMovie[r.movie_id]) {
      byMovie[r.movie_id] = { movie_id: r.movie_id, movie_title: r.movie_title, genre: r.genre, ratings: [] }
    }
    byMovie[r.movie_id].ratings.push(r.rating)
  })
  return Object.values(byMovie)
    .filter((m) => m.ratings.length >= 3) // avoid noisy "highest rated" from 1-2 ratings
    .map((m) => ({
      movie_id: m.movie_id,
      movie_title: m.movie_title,
      genre: m.genre,
      ratingCount: m.ratings.length,
      avgRating: avg(m.ratings),
    }))
}

export function genreAnalysis(ratings) {
  const genres = uniqueGenres(ratings)
  return genres.map((genre) => {
    const genreRatings = ratings.filter((r) => r.genre === genre)
    const viewers = new Set(genreRatings.map((r) => r.user_id)).size
    return {
      genre,
      ratingCount: genreRatings.length,
      avgRating: avg(genreRatings.map((r) => r.rating)),
      viewerCount: viewers,
    }
  })
}

export function ratingDistribution(ratings) {
  const buckets = [1, 2, 3, 4, 5].map((r) => ({ rating: String(r), count: 0 }))
  ratings.forEach((r) => {
    const bucket = buckets.find((b) => Number(b.rating) === r.rating)
    if (bucket) bucket.count += 1
  })
  return buckets
}

export function medianRating(ratings) {
  const sorted = [...ratings.map((r) => r.rating)].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2
}

export function mostCommonRating(ratings) {
  const counts = {}
  ratings.forEach((r) => { counts[r.rating] = (counts[r.rating] || 0) + 1 })
  return Number(Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0])
}
