import React, { useEffect, useMemo, useState } from 'react'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Dashboard from './pages/Dashboard'
import AudienceSegments from './pages/AudienceSegments'
import RatingAnalysis from './pages/RatingAnalysis'
import ClusterPerformance from './pages/ClusterPerformance'
import { loadDataset } from './services/dataset'
import { segmentViewers } from './ml/clustering'
import { computeClusterStats, nameSegments } from './utils/segmentInsights'

const STAGE_LABEL = {
  'loading-data': 'Loading Movie Ratings…',
  preparing: 'Preparing viewer profiles…',
  features: 'Building rating features…',
  normalizing: 'Normalizing data…',
  clustering: 'Training K-Means…',
  generating: 'Generating audience segments…',
}

export default function App() {
  const [page, setPage] = useState('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)

  const [ratings, setRatings] = useState(null)
  const [stage, setStage] = useState('loading-data')
  const [error, setError] = useState(null)
  const [k, setK] = useState(4)
  const [result, setResult] = useState(null)
  const [recomputing, setRecomputing] = useState(false)

  useEffect(() => {
    let cancelled = false
    async function run() {
      try {
        const data = await loadDataset()
        if (cancelled) return
        setStage('preparing')
        setRatings(data)

        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return
        setStage('features')

        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return
        setStage('normalizing')

        await new Promise((r) => setTimeout(r, 120))
        if (cancelled) return
        setStage('clustering')

        const clusterResult = segmentViewers(data, 4)
        if (cancelled) return
        setStage('generating')

        await new Promise((r) => setTimeout(r, 150))
        if (cancelled) return
        setResult(clusterResult)
        setStage('ready')
      } catch (err) {
        if (!cancelled) {
          setError(err.message || 'Something went wrong loading the app.')
          setStage('error')
        }
      }
    }
    run()
    return () => { cancelled = true }
  }, [])

  const handleKChange = (newK) => {
    if (!ratings || newK === k) return
    setRecomputing(true)
    setTimeout(() => {
      const clusterResult = segmentViewers(ratings, newK)
      setResult(clusterResult)
      setK(newK)
      setRecomputing(false)
    }, 30)
  }

  const segments = useMemo(() => {
    if (!result) return []
    const stats = computeClusterStats(result.viewers, result.k)
    return nameSegments(result.viewers, stats)
  }, [result])

  const status = stage === 'ready' ? (recomputing ? 'loading' : 'ready') : stage === 'error' ? 'error' : 'loading'

  if (stage !== 'ready' && stage !== 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm">
          <p className="font-display text-2xl text-ink mb-2">Movie Audience Segmentation</p>
          <p className="text-sm text-ink/50 mb-6">{STAGE_LABEL[stage]}</p>
          <div className="w-full h-1.5 bg-black/10 rounded-full overflow-hidden">
            <div className="h-full bg-indigo3 animate-pulse" style={{ width: '70%' }} />
          </div>
        </div>
      </div>
    )
  }

  if (stage === 'error') {
    return (
      <div className="min-h-screen flex items-center justify-center bg-paper px-6">
        <div className="text-center max-w-sm bg-white border border-black/5 rounded-lg p-6">
          <p className="font-display text-xl text-ink mb-2">Couldn't start the app</p>
          <p className="text-sm text-ink/60">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen md:flex">
      <Sidebar activePage={page} onNavigate={setPage} open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 min-w-0">
        <Header activePage={page} onMenuClick={() => setSidebarOpen(true)} status={status} k={k} />
        <main className="p-4 md:p-8 min-w-0">
          {page === 'dashboard' && (
            <Dashboard ratings={ratings} viewers={result.viewers} segments={segments} k={k} />
          )}
          {page === 'segments' && (
            <AudienceSegments
              ratings={ratings}
              viewers={result.viewers}
              segments={segments}
              k={k}
              onKChange={handleKChange}
              clustering={result}
            />
          )}
          {page === 'analysis' && (
            <RatingAnalysis ratings={ratings} viewers={result.viewers} genres={result.genres} segments={segments} />
          )}
          {page === 'performance' && (
            <ClusterPerformance viewers={result.viewers} segments={segments} k={k} clustering={result} />
          )}
        </main>
      </div>
    </div>
  )
}
